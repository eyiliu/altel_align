//============================================================================
// Name        : GBLpp.cpp
// Author      : Claus Kleinwort - DESY
// Version     : initial development
// Description : General Broken Lines in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void example1();

int main() {
	example1();
	return 0;
}
