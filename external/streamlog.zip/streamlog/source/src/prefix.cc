#include "streamlog/prefix.h"

namespace streamlog{

  prefix_base::prefix_base() : _name("UNKOWN") , _levelName("VERBOSE") {
  }
  
  prefix_base::~prefix_base() {
  }
}
